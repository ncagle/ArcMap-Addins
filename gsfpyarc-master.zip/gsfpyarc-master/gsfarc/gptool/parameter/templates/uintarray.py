"""

"""
from .basicarray import BASICARRAY


class UINTARRAY(BASICARRAY): pass


def template():
    return UINTARRAY('GPLong')