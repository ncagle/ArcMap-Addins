"""

"""
from .basic import BASIC


class BOOLEAN(BASIC): pass

def template():
    return BOOLEAN('GPBoolean')