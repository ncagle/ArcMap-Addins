"""

"""

from .basic import BASIC


class LONG(BASIC): pass

def template():
    return LONG('GPLong')