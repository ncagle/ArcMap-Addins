"""

"""

from .basicarray import BASICARRAY


class LONGARRAY(BASICARRAY): pass

def template():
    return LONGARRAY('GPLong')