"""

"""

from .basicarray import BASICARRAY


class ULONG64ARRAY(BASICARRAY): pass

def template():
    return ULONG64ARRAY('GPLong')