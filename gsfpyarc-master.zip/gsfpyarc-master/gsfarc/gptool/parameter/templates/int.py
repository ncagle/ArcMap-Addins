"""

"""

from .basic import BASIC


class INT(BASIC): pass

def template():
    return INT('GPLong')