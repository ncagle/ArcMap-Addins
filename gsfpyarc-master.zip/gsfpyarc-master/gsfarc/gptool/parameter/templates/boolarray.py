"""

"""



from .basicarray import BASICARRAY


class BOOLARRAY(BASICARRAY):
    pass


def template():
    return BOOLARRAY('GPBoolean')