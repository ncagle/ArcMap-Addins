"""

"""
from .basic import BASIC


class UINT(BASIC): pass


def template():
    return UINT('GPLong')