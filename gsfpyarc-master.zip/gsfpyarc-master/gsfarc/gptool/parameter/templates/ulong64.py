"""

"""

from .basic import BASIC


class ULONG64(BASIC): pass

def template():
    return ULONG64('GPLong')