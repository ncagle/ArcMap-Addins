"""

"""



from .basicarray import BASICARRAY


class INTARRAY(BASICARRAY):
    pass


def template():
    return INTARRAY('GPLong')