"""

"""
from .basic import BASIC


class BOOL(BASIC): pass

def template():
    return BOOL('GPBoolean')