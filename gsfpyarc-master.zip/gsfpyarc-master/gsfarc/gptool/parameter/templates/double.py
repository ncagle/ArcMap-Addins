"""

"""

from .basic import BASIC


class DOUBLE(BASIC): pass


def template():
    return DOUBLE('GPDouble')
