"""

"""

from .basic import BASIC


class LONG64(BASIC): pass

def template():
    return LONG64('GPLong')