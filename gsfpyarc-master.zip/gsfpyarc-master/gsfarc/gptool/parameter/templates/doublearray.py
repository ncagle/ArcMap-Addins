"""

"""

from .basicarray import BASICARRAY


class DOUBLEARRAY(BASICARRAY): pass


def template():
    return DOUBLEARRAY('GPDouble')
