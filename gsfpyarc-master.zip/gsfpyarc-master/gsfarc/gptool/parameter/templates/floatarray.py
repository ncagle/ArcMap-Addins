"""

"""

from .basicarray import BASICARRAY


class FLOATARRAY(BASICARRAY): pass


def template():
    return FLOATARRAY('GPDouble')
