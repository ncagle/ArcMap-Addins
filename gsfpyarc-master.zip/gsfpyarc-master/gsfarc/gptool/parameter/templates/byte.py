"""

"""

from .basic import BASIC


class BYTE(BASIC): pass

def template():
    return BYTE('GPLong')