"""

"""



from .basicarray import BASICARRAY


class STRINGARRAY(BASICARRAY):
    pass


def template():
    return STRINGARRAY('GPString')