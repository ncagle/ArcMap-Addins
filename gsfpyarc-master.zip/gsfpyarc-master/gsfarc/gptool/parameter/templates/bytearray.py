"""

"""



from .basicarray import BASICARRAY


class BYTEARRAY(BASICARRAY):
    pass


def template():
    return BYTEARRAY('GPLong')