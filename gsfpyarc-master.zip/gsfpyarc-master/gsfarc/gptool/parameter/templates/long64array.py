"""

"""

from .basicarray import BASICARRAY


class LONG64ARRAY(BASICARRAY): pass

def template():
    return LONG64ARRAY('GPLong')