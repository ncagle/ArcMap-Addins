"""

"""

from .basic import BASIC


class ULONG(BASIC): pass

def template():
    return ULONG('GPLong')