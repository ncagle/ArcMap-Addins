"""

"""

from .basicarray import BASICARRAY


class ULONGARRAY(BASICARRAY): pass

def template():
    return ULONGARRAY('GPLong')