"""

"""

from .basic import BASIC


class FLOAT(BASIC): pass


def template():
    return FLOAT('GPDouble')
